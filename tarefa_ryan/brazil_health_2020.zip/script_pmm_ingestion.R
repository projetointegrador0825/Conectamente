### LOAD PACKAGES

library(tidyverse)
library(lubridate)
library(hablar)
library(rio)


### DATA IMPORT

pmm_crude <- import("./pmm_data_raw/pmm_proadess.zip", skip = 5, na = c("-", "s/i"), col_types = "text")

glimpse(pmm_crude)


### DATA CLEANING (I)

pmm_clean <- 
  pmm_crude %>% 
  rename("MEDICO_NOME" = "Nome do Profissional",
         "DT_INICIO" = "Inicio das Atividades",
         "DT_FIM" = "Fim das Atividades",
         "LOCAL_CODIGO" = "IBGE",
         "LOCAL_NOME" = "Municipio/DSEI de Atuacao do Profissional") %>% 
  select(CPF, MEDICO_NOME, UF, LOCAL_NOME, LOCAL_CODIGO, DT_INICIO, DT_FIM) %>% 
  mutate_at(c("DT_INICIO", "DT_FIM"), ~openxlsx::convertToDate(.)) %>% 
  mutate(DT_FIM = replace_na(DT_FIM, as_date("2018-12-31"))) %>% 
  mutate(DT_INICIO2 = ifelse(DT_INICIO > DT_FIM, DT_FIM, DT_INICIO)) %>% 
  mutate(DT_FIM2 = ifelse(DT_INICIO > DT_FIM, DT_INICIO, DT_FIM)) %>% 
  mutate_at(c("DT_INICIO2", "DT_FIM2"), ~as_date(.)) %>% 
  mutate(DT_INICIO = DT_INICIO2, DT_FIM = DT_FIM2) %>% 
  mutate(DIAS_TRAB = time_length(interval(DT_INICIO, DT_FIM), unit = "day")) %>% 
  mutate(DIAS_TRAB = as.integer(round(DIAS_TRAB, digits = 0))) %>% # # FILTRAR DIAS DE TRABALHO = 0?
  mutate(DT_INICIO2 = floor_date(DT_INICIO, unit = "month")) %>% 
  mutate(DT_FIM2 = floor_date(DT_FIM, unit = "month")) %>% 
  mutate(MES_TRAB = time_length(interval(DT_INICIO2, DT_FIM2), unit = "month")) %>% 
  retype() %>% 
  distinct()


### SEARCH MUNIC

source("fc_search_munic.R")

tb <- 
  pmm_clean %>% 
  filter(is.na(LOCAL_CODIGO)) %>% 
  rename("name_state" = "UF", "name_munic" = "LOCAL_NOME") %>% 
  select(name_state, name_munic) %>% 
  distinct()

tb <- search_munic(tb, name_state, name_munic)


### DATA CLEANING (II)

pmm_clean <- 
  pmm_clean %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~as.character(.)) %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~abjutils::rm_accent(.)) %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~str_replace_all(., "[^[:alpha:]]", " ")) %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~str_to_upper(.)) %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~str_trim(., side = "both")) %>% 
  mutate_at(c("UF", "LOCAL_NOME"), ~str_squish(.)) %>% 
  mutate(LOCAL_CODIGO = ifelse(is.na(LOCAL_CODIGO) & UF %in% tb$name_state & 
                                 LOCAL_NOME %in% tb$name_munic, tb$local_code, LOCAL_CODIGO))


### DATA CLEANING (III)

pmm_clean <- 
  pmm_clean %>% 
  mutate(NU_ROW = 1:nrow(.)) %>% 
  split(.$NU_ROW)


t0 <- Sys.time()

for(i in seq_along(pmm_clean)){
  
  tempdf <- 
    pmm_clean[i] %>% 
    flatten_df() %>% 
    mutate(DT_ATUACAO = list(DT_INICIO2 + months(seq(0, MES_TRAB, 1)))) %>% 
    unnest(DT_ATUACAO)
  
  data.table::fwrite(tempdf, "./pmm_data_treated/pmm_crude_data.csv", sep = ";", append = T)
  
  }

Sys.time() - t0 # 5.145318 mins


### DATA CLEANING (IV)

pmm_clean <- import("./pmm_data_treated/pmm_crude_data.csv")

pmm_clean <- 
  pmm_clean %>% 
  rename("LOCAL_CODE" = "LOCAL_CODIGO") %>% 
  select(CPF, MEDICO_NOME, LOCAL_CODE, DT_ATUACAO) %>% 
  distinct() %>% 
  mutate(YEAR = year(DT_ATUACAO)) %>% 
  mutate(MONTH = month(DT_ATUACAO)) %>% 
  mutate(LOCAL_CODE = as.integer(str_sub(LOCAL_CODE, end = 6))) %>% 
  mutate(LOCAL_CODE = case_when(LOCAL_CODE == 405306 ~ 240530L,
                                LOCAL_CODE == 515401 ~ 251540L,
                                TRUE ~ LOCAL_CODE)) %>% 
  mutate(LOCAL_CODE = ifelse(str_detect(LOCAL_CODE, "^53"), 530010L, LOCAL_CODE)) %>% 
  group_by(LOCAL_CODE, YEAR, MONTH) %>% 
  summarise(FL_PMM = 1L,
            NU_PHYSICIAN_PMM = n(), .groups = "drop")


pmm_clean <- 
  bind_rows(
    pmm_clean %>% 
      group_by(LOCAL_CODE = 76L, YEAR, MONTH, FL_PMM) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    pmm_clean %>% 
      mutate(LOCAL_CODE = as.integer(str_sub(LOCAL_CODE, end = 1))) %>% 
      group_by(LOCAL_CODE, YEAR, MONTH, FL_PMM) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    pmm_clean %>% 
      mutate(LOCAL_CODE = as.integer(str_sub(LOCAL_CODE, end = 2))) %>% 
      group_by(LOCAL_CODE, YEAR, MONTH, FL_PMM) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    pmm_clean)


glimpse(pmm_clean)


### DATA SELFIE

print(summarytools::dfSummary(pmm_clean, graph.col = F), method = "viewer", file = "pmm_sprint_dataselfie.html")


### SAVE DATA

save(pmm_clean, file = "./pmm_data_treated/pmm_clean_data.RData")

