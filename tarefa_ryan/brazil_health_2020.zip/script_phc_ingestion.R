### SOURCE (Manual Data Extraction, 04/12/2021)

# https://egestorab.saude.gov.br/paginas/acessoPublico/relatorios/relHistoricoCoberturaAB.xhtml


### LOAD PACKAGES

t0 <- Sys.time()

library(tidyverse)
library(hablar)
library(rio)


### DATA IMPORT (Updated: 22/04/2021)

phc_crudeO <- import_list(c("./phc_data_raw/HISTORICO-1998-2010.zip",
                            "./phc_data_raw/HISTORICO-2011-2019.zip"), rbind = T)

phc_crudeN <- import_list("./phc_data_raw/Historico-AB-MUNICIPIOS-2007-202012.xlsx",
                          setclass = "tbl", which = 1:14, rbind = T)


### DATA CLEANING

df_base <- import("./ls_munic_pop.txt")

phc_cleanO <- 
  phc_crudeO %>% 
  rename("YEAR" = "ANO", "MONTH" = "MES", "NU_TEAM_FH" = "ESF Implantada") %>% 
  mutate(LOCAL_CODE = str_sub(`C�digo`, end = 6)) %>% 
  mutate(LOCAL_CODE = ifelse(str_detect(LOCAL_CODE, "^53"), "530010", LOCAL_CODE)) %>% 
  select(LOCAL_CODE, YEAR, MONTH, NU_TEAM_FH) %>% 
  mutate(NU_TEAM_FH = replace_na(NU_TEAM_FH, 0L)) %>% 
  retype()

phc_cleanN <- 
  phc_crudeN %>% 
  mutate(LOCAL_CODE = str_sub(CO_MUNICIPIO_IBGE, end = 6)) %>% 
  mutate(LOCAL_CODE = ifelse(str_detect(LOCAL_CODE, "^53"), "530010", LOCAL_CODE)) %>% 
  mutate(YEAR = str_sub(NU_COMPETENCIA, end = 4)) %>% 
  mutate(MONTH = str_sub(NU_COMPETENCIA, start = -2)) %>% 
  select(LOCAL_CODE, YEAR, MONTH, starts_with("QT_EQUIPE_"), -QT_EQUIPE_SF_AB) %>% 
  mutate_all(., ~str_remove_all(., "\\.")) %>% 
  mutate_at(vars(starts_with("QT_EQUIPE")), ~replace_na(., 0L)) %>% 
  retype() %>% 
  rename("NU_TEAM_FH" = "QT_EQUIPE_SF", "NU_TEAM_BH_PAR" = "QT_EQUIPE_AB_PARAMETRIZADA", "NU_TEAM_BH_EQU" = "QT_EQUIPE_AB_EQUIVALENTE_CH")

phc_clean <- 
  phc_cleanN %>% 
  full_join(phc_cleanO, by = c("YEAR", "MONTH", "LOCAL_CODE"), suffix = c("", "_OLD")) %>% 
  mutate(NU_TEAM_FH = ifelse(is.na(NU_TEAM_FH), NU_TEAM_FH_OLD, NU_TEAM_FH))

phc_clean <- 
  df_base %>% 
  filter(YEAR >= 1998) %>% 
  left_join(phc_clean, by = c("LOCAL_CODE", "YEAR")) %>% 
  mutate(MONTH = replace_na(MONTH, 12L)) %>% 
  mutate_at(vars(starts_with("NU_")), ~replace_na(., 0L)) %>% 
  mutate(NU_TEAM_FH_BH = NU_TEAM_FH + NU_TEAM_BH_PAR + NU_TEAM_BH_EQU) %>% 
  mutate(NU_COVERAGE_FH = 3450 * NU_TEAM_FH) %>% 
  mutate(NU_COVERAGE_BH = 3000 * (NU_TEAM_BH_PAR + NU_TEAM_BH_EQU)) %>% 
  mutate(NU_COVERAGE_FH_BH = NU_COVERAGE_FH + NU_COVERAGE_BH) %>% 
  mutate_at(vars(starts_with("NU_COVERAGE_")), ~ifelse(. > POPULATION, POPULATION, .)) %>% 
  select(LOCAL_CODE, YEAR, MONTH, POPULATION, NU_TEAM_FH_OLD, NU_TEAM_FH, everything()) %>% 
  retype()

phc_clean <- 
  bind_rows(
    phc_clean %>% 
      group_by(LOCAL_CODE = 76L, YEAR, MONTH) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    phc_clean %>% 
      mutate(LOCAL_CODE = as.integer(str_sub(LOCAL_CODE, end = 1))) %>% 
      group_by(LOCAL_CODE, YEAR, MONTH) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    phc_clean %>% 
      mutate(LOCAL_CODE = as.integer(str_sub(LOCAL_CODE, end = 2))) %>% 
      group_by(LOCAL_CODE, YEAR, MONTH) %>% 
      summarise_all(sum_) %>% 
      ungroup(),
    
    phc_clean)

glimpse(phc_clean)


### DATA SELFIE

print(summarytools::dfSummary(phc_clean, graph.col = F), method = "viewer", file = "phc_sprint_dataselfie.html")


### SAVE DATA

save(phc_clean, file = "./phc_data_treated/phc_clean_data.RData")


Sys.time() - t0 # 36.22316 secs
