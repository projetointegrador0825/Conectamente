### LOAD PACKAGES

t0 <- Sys.time()

library(tidyverse)
library(hablar)


### DATA IMPORT

load("./master/basics/data_sets/basics_master_data.RData")
load("./sprints/phc/phc_data_treated/phc_clean_data.RData")
load("./sprints/pmm/pmm_data_treated/pmm_clean_data.RData")


### DATA INTEGRATION AND HARMONIZATION

phc_data <- 
  basics_data %>% 
  filter(YEAR >= 1998) %>% 
  select(-starts_with(c("POPULATION_U1", "POPULATION_Y1"))) %>% 
  left_join(phc_clean %>% 
              select(-POPULATION), by = c("LOCAL_CODE", "YEAR"))


### DATA CLEANING

phc_data <- 
  phc_data %>% 
  #mutate(MONTH = replace_na(MONTH, 12L)) %>% 
  #mutate_at(vars(starts_with("NU_")), ~replace_na(., 0L)) %>% 
  #mutate_at(vars(starts_with("NU_COVERAGE_")), ~ifelse(. > POPULATION, POPULATION, .)) %>% 
  mutate(PC_COVERAGE_FH = round((NU_COVERAGE_FH/POPULATION) * 100, 2)) %>% 
  mutate(PC_COVERAGE_BH = round((NU_COVERAGE_BH/POPULATION) * 100, 2)) %>% 
  mutate(PC_COVERAGE_FH_BH = round((NU_COVERAGE_FH_BH/POPULATION) * 100, 2)) %>% 
  select(1:6, MONTH, everything()) 

phc_data <- 
  phc_data %>% 
  left_join(pmm_clean, by = c("LOCAL_CODE", "YEAR", "MONTH")) %>% 
  mutate_at(c("FL_PMM", "NU_PHYSICIAN_PMM"), ~replace_na(., 0L))

glimpse(phc_data)


### DATA SELFIE

format(object.size(phc_data), units = "MB") # 311.4 Mb
print(summarytools::dfSummary(phc_data, graph.col = F), method = "viewer", file = "./master/phc/data_files/phc_master_dataselfie.html")


### SAVE DATA

save(phc_data, file = "./master/phc/data_sets/phc_master_data.RData")


Sys.time() - t0 # 34.93618 secs
